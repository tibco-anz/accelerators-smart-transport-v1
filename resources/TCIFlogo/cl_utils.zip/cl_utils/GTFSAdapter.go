/*******************************
*** Name: GTFSAdapter
*** Date: 2020 Dec 06
*** Author: Charlea Law (TIBCO Sydney)
***
*** Description:
*** Custom extension function to convert GTFS transport protobuf message to Json format containing an array of entities only (without the header).
***
*** Usage:
*** GTSFSAdapter(ProtobufMessage(string), EntitySize(int), Transform(bool))
***
*** Parameters:
*** 1). ProtobufMessage
*** The protobuf message to be converted to Json
*** 2). EntitySize
*** The total number of entities will be returned in the Json string by the function
*** (If n = actual number of entity in the message)
*** When EntitySize <= 0, return all entities in the message (i.e. n)
*** When EntitySize > 0 and < n, return the number of entity specified in this parameter
*** When EntitySize >= n, return all entities in the message (i.e. n)
*** 3). Transform
*** When true, the Json output will contain the transformed entities (currently the transformation structure is hard coded)
*** When false, the Json output will contain the orginal structure of the entities
***
********************************/
package cl_utils

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"log"
	"strconv"
	"strings"

	"github.com/project-flogo/core/data"
	"github.com/project-flogo/core/data/expression/function"

	"github.com/golang/protobuf/jsonpb"
	"github.com/golang/protobuf/proto"

	pb "sydBusDemo.org/pb"
)

func init() {
	function.Register(&fnP2JU{})
}

type fnP2JU struct {
}

func (fnP2JU) Name() string {
	return "GTFSAdapter"
}

func (fnP2JU) Sig() (paramTypes []data.Type, isVariadic bool) {
	return []data.Type{data.TypeString, data.TypeInt, data.TypeBool}, false
}

func (fnP2JU) Eval(params ...interface{}) (interface{}, error) {
	return parseGTFSMessage(params[0].(string), params[1].(int), params[2].(bool)), nil
}

func parseGTFSMessage(ProtoBuf64 string, EntitySize int, Transform bool) string {

	fmt.Println("=======GTFSAdapter=======")
	fmt.Println("EntitySize:", strconv.Itoa(EntitySize))
	fmt.Println("Transform:", strconv.FormatBool(Transform))

	/********************
	Protobuf to Json conversion
	*********************/
	protoBufByte, errDecode := Base64Decode2([]byte(ProtoBuf64))
	if errDecode != nil {
		log.Fatalln("Failed to convert protobuf message:", errDecode)
	}

	feedMessage := &pb.FeedMessage{}
	if err := proto.Unmarshal(protoBufByte, feedMessage); err != nil {
		log.Fatalln("Failed to parse feedMessage:", err)
	}

	jsonString, _ := Protobuf2JSON(feedMessage)

	/********************
	Json string transformation
	*********************/
	var jsonStruct map[string]interface{}
	if err := json.Unmarshal([]byte(jsonString), &jsonStruct); err != nil {
		panic(err)
	}

	entityArrayInf := jsonStruct["entity"].([]interface{})

	// Determine outEntitySize
	totalEntitySize := len(entityArrayInf)
	var outEntitySize int
	if int(EntitySize) <= 0 {
		outEntitySize = totalEntitySize
	} else {
		if int(EntitySize) < totalEntitySize {
			outEntitySize = int(EntitySize)
		} else {
			outEntitySize = totalEntitySize
		}
	}

	// to hold collection of individual messages
	var outArrayMap []map[string]interface{}
	outArrayMap = make([]map[string]interface{}, outEntitySize)

	for i := 0; i < outEntitySize; i++ {
		entityMap := entityArrayInf[i].(map[string](interface{}))

		// Skip entity when they have missing sub-parents
		entityVehicleMap := entityMap["vehicle"].(map[string](interface{}))
		if entityVehicleMap["trip"] == nil || entityVehicleMap["position"] == nil {
			continue
		}

		if Transform {
			/*			entityVehicleMap := entityMap["vehicle"].(map[string](interface{}))
						if entityVehicleMap["trip"] == nil || entityVehicleMap["position"] == nil {
							continue
						}
			*/entityVehicleTripMap := entityVehicleMap["trip"].(map[string](interface{}))
			entityVehiclePosMap := entityVehicleMap["position"].(map[string](interface{}))

			outArrayMap[i] = make(map[string]interface{})
			outArrayMap[i]["id"] = entityMap["id"]
			outArrayMap[i]["timestamp"] = entityVehicleMap["timestamp"]
			outArrayMap[i]["congestion_level"] = entityVehicleMap["congestion_level"]
			outArrayMap[i]["occupancy_status"] = entityVehicleMap["occupancy_status"]
			outArrayMap[i]["route_id"] = strings.Split(entityVehicleTripMap["route_id"].(string), "_")[1]
			outArrayMap[i]["trip_id"] = entityVehicleTripMap["trip_id"]
			outArrayMap[i]["start_time"] = entityVehicleTripMap["start_time"]
			outArrayMap[i]["start_date"] = entityVehicleTripMap["start_date"]
			outArrayMap[i]["schedule_relationship"] = entityVehicleTripMap["schedule_relationship"]
			outArrayMap[i]["latitude"] = entityVehiclePosMap["latitude"]
			outArrayMap[i]["longitude"] = entityVehiclePosMap["longitude"]
			outArrayMap[i]["bearing"] = entityVehiclePosMap["bearing"]
			if entityVehiclePosMap["speed"] == nil {
				continue
			}
			outArrayMap[i]["speed"] = entityVehiclePosMap["speed"].(float64) * 3.6

		} else {

			outArrayMap[i] = entityMap
		}
	}

	respMsgMap := make(map[string]interface{})
	respMsgMap["respMsg"] = outArrayMap

	respMsgJson, _ := json.Marshal(respMsgMap)
	respMsgJson64 := Base64Encode2(respMsgJson)

	return string(respMsgJson64)
}

/********
***	 Helper functions
********/
// ProtobufToJSON converts protocol buffer message to JSON string
func Protobuf2JSON(message proto.Message) (string, error) {
	marshaler := jsonpb.Marshaler{
		EnumsAsInts:  false,
		EmitDefaults: true,
		Indent:       "  ",
		OrigName:     true,
	}
	return marshaler.MarshalToString(message)
}

func Base64Encode2(message []byte) []byte {
	b := make([]byte, base64.StdEncoding.EncodedLen(len(message)))
	base64.StdEncoding.Encode(b, message)
	return b
}

func Base64Decode2(message []byte) (b []byte, err error) {
	var l int
	b = make([]byte, base64.StdEncoding.DecodedLen(len(message)))
	l, err = base64.StdEncoding.Decode(b, message)
	if err != nil {
		return
	}
	return b[:l], nil
}
