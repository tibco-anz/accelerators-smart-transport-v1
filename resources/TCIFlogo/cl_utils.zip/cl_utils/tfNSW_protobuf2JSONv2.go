/*******************************
*** Date: 2020 Nov 27
*** Author: Charlea Law (TIBCO Sydney)
***
*** Custom function extension used to convert gtfs transport protobuf message to Json.
*** Features:
*** - Split the message to smaller trunks based on entity size input (Default is 25)
*** - All individual messages created are grouped together by a json wrapper.
*** The whole wrapper message will be returned by the function
*** - IsTestMode, when test mode is set to true, the entity size is set to the 5.
*** It means only the first 5 entities are used by the function to generate the json
********************************/
package cl_utils

import (
	"encoding/json"
	"fmt"
	"log"
	"math"
	"strconv"

	"github.com/project-flogo/core/data"
	"github.com/project-flogo/core/data/expression/function"

	"github.com/golang/protobuf/proto"

	pb "sydBusDemo.org/pb"
)

func init() {
	function.Register(&fnP2J2{})
}

type fnP2J2 struct {
}

func (fnP2J2) Name() string {
	return "tfNSW_protobuf2JSONv2"
}

func (fnP2J2) Sig() (paramTypes []data.Type, isVariadic bool) {
	return []data.Type{data.TypeString, data.TypeInt, data.TypeBool}, false
}

func (fnP2J2) Eval(params ...interface{}) (interface{}, error) {
	return parseMessagev2(params[0].(string), params[1].(int), params[2].(bool)), nil
}

func parseMessagev2(protoBuf64 string, batchSize int, isTest bool) string {

	fmt.Println("=======tfNSW=======")
	fmt.Println("Batch Size:" + strconv.Itoa(batchSize))
	fmt.Println("Test Mode:" + strconv.FormatBool(isTest))

	protoBufByte, errDecode := Base64Decode([]byte(protoBuf64))
	if errDecode != nil {
		log.Fatalln("Failed to convert protobuf message:", errDecode)
	}

	// Instantiate FeedMessage structure
	feedMessage := &pb.FeedMessage{}
	if err := proto.Unmarshal(protoBufByte, feedMessage); err != nil {
		log.Fatalln("Failed to parse feedMessage:", err)
	}

	jsonString, _ := ProtobufToJSON(feedMessage)

	// Store output json string to jsonStruct structure
	var jsonStruct map[string]interface{}
	if err := json.Unmarshal([]byte(jsonString), &jsonStruct); err != nil {
		panic(err)
	}

	// Varibales to hold the header and entities
	headerInf := jsonStruct["header"]
	entityArrayInf := jsonStruct["entity"].([]interface{})

	// For Test mode, use subset of message
	if isTest {
		entityArrayInf = entityArrayInf[0:5]
	}

	entitySizeInt := len(entityArrayInf)
	const defaultEntitySize = 5
	var batchSizeInt int
	if int(batchSize) <= 0 {
		if defaultEntitySize <= entitySizeInt {
			batchSizeInt = defaultEntitySize
		} else {
			batchSizeInt = entitySizeInt
		}
	} else {
		if int(batchSize) <= entitySizeInt {
			batchSizeInt = int(batchSize)
		} else {
			batchSizeInt = entitySizeInt
		}
	}

	var loopSizeInt int
	loopSizeInt = int(math.Floor(float64(entitySizeInt) / float64(batchSizeInt)))

	// Determine the size of messageBucketArrayInf to hold the all the splite messages
	var messageSizeInt int
	if entitySizeInt > int(loopSizeInt*batchSizeInt) {
		messageSizeInt = loopSizeInt + 1
	} else {
		messageSizeInt = loopSizeInt
	}

	fmt.Println("Total/Test Entity Size:" + strconv.Itoa(entitySizeInt))
	fmt.Println("Derived Batch Size:" + strconv.Itoa(batchSizeInt))
	fmt.Println("Derived Loop Size:" + strconv.Itoa(loopSizeInt+1))
	fmt.Println("Derived Message Size:" + strconv.Itoa(messageSizeInt))

	// to hold collection of individual messages
	messageBucketArrayInf := make([]map[string]interface{}, messageSizeInt)

	// Process spliting the messages and add each of them to messageBucketArrayInf
	var entityOffsetInt int
	for i := 0; i <= loopSizeInt; i++ {
		// Check if it is the last batch of entities
		if i == loopSizeInt {
			if entitySizeInt > int(i*batchSizeInt) {
				entityOffsetInt = entitySizeInt
			} else {
				break
			}
		} else {
			entityOffsetInt = int(i*batchSizeInt + batchSizeInt)
		}
		messageBucketArrayInf[i] = make(map[string]interface{})
		messageBucketArrayInf[i]["header"] = headerInf
		messageBucketArrayInf[i]["entity"] = entityArrayInf[int(i*batchSizeInt):entityOffsetInt]
	}

	respMsgMap := make(map[string]interface{})
	respMsgMap["respMsg"] = messageBucketArrayInf

	respMsgJson, _ := json.Marshal(respMsgMap)
	respMsgJson64 := Base64Encode(respMsgJson)

	/*	if (len(respMsgJson64)) > 0 {
			fmt.Println("Hello")
		}
	*/ //newtext := "{entitySizeInt: " + strconv.Itoa(entitySizeInt) + "|| loopSizeInt: " + strconv.Itoa(loopSizeInt) + "}"
	return string(respMsgJson64)
}

/********
***	 Helper functions
********/
/*
// ProtobufToJSON converts protocol buffer message to JSON string
func ProtobufToJSON(message proto.Message) (string, error) {
	marshaler := jsonpb.Marshaler{
		EnumsAsInts:  false,
		EmitDefaults: true,
		Indent:       "  ",
		OrigName:     true,
	}
	return marshaler.MarshalToString(message)
}

func Base64Encode(message []byte) []byte {
	b := make([]byte, base64.StdEncoding.EncodedLen(len(message)))
	base64.StdEncoding.Encode(b, message)
	return b
}

func Base64Decode(message []byte) (b []byte, err error) {
	var l int
	b = make([]byte, base64.StdEncoding.DecodedLen(len(message)))
	l, err = base64.StdEncoding.Decode(b, message)
	if err != nil {
		return
	}
	return b[:l], nil
}
*/
