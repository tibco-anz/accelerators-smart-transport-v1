/*******************************
*** Date: 2020 Nov 27
*** Author: Charlea Law (TIBCO Sydney)
***
*** Custom function extension used to convert gtfs transport protobuf message to Json.
*** Features:
*** - Split the message to smaller trunks based on entity size input (Default is 25)
*** - All individual messages created are grouped together by a json wrapper.
*** The whole wrapper message will be returned by the function
*** - IsTestMode, when test mode is set to true, the entity size is set to the 5.
*** It means only the first 5 entities are used by the function to generate the json
********************************/
package cl_utils

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"log"
	"math"
	"strconv"
	"strings"

	"github.com/project-flogo/core/data"
	"github.com/project-flogo/core/data/expression/function"

	"github.com/golang/protobuf/jsonpb"
	"github.com/golang/protobuf/proto"

	pb "sydBusDemo.org/pb"
)

func init() {
	function.Register(&fnP2J{})
}

type fnP2J struct {
}

func (fnP2J) Name() string {
	return "tfNSW_protobuf2JSON"
}

func (fnP2J) Sig() (paramTypes []data.Type, isVariadic bool) {
	return []data.Type{data.TypeString, data.TypeInt, data.TypeBool}, false
}

func (fnP2J) Eval(params ...interface{}) (interface{}, error) {
	return parseMessage(params[0].(string), params[1].(int), params[2].(bool)), nil
}

func parseMessage(protoBuf64 string, batchSize int, isTest bool) string {

	fmt.Println("=======tfNSW=======")
	fmt.Println("Batch Size:" + strconv.Itoa(batchSize))
	fmt.Println("Test Mode:" + strconv.FormatBool(isTest))

	protoBufByte, errDecode := Base64Decode([]byte(protoBuf64))
	if errDecode != nil {
		log.Fatalln("Failed to convert protobuf message:", errDecode)
	}

	// Instantiate FeedMessage structure
	feedMessage := &pb.FeedMessage{}
	if err := proto.Unmarshal(protoBufByte, feedMessage); err != nil {
		log.Fatalln("Failed to parse feedMessage:", err)
	}

	jsonString, _ := ProtobufToJSON(feedMessage)

	// Store output json string to jsonStruct structure
	var jsonStruct map[string]interface{}
	if err := json.Unmarshal([]byte(jsonString), &jsonStruct); err != nil {
		panic(err)
	}

	// Varibales to hold the header and entities
	//	headerInf := jsonStruct["header"]
	entityArrayInf := jsonStruct["entity"].([]interface{})

	// For Test mode, use subset of message
	if isTest {
		entityArrayInf = entityArrayInf[0:5]
	}

	entitySizeInt := len(entityArrayInf)
	const defaultEntitySize = 5
	var batchSizeInt int
	if int(batchSize) <= 0 {
		if defaultEntitySize <= entitySizeInt {
			batchSizeInt = defaultEntitySize
		} else {
			batchSizeInt = entitySizeInt
		}
	} else {
		if int(batchSize) <= entitySizeInt {
			batchSizeInt = int(batchSize)
		} else {
			batchSizeInt = entitySizeInt
		}
	}

	var loopSizeInt int
	loopSizeInt = int(math.Floor(float64(entitySizeInt) / float64(batchSizeInt)))

	// Determine the size of messageBucketArrayInf to hold the all the splite messages
	var messageSizeInt int
	if entitySizeInt > int(loopSizeInt*batchSizeInt) {
		messageSizeInt = loopSizeInt + 1
	} else {
		messageSizeInt = loopSizeInt
	}

	fmt.Println("Total/Test Entity Size:" + strconv.Itoa(entitySizeInt))
	fmt.Println("Derived Batch Size:" + strconv.Itoa(batchSizeInt))
	fmt.Println("Derived Loop Size:" + strconv.Itoa(loopSizeInt+1))
	fmt.Println("Derived Message Size:" + strconv.Itoa(messageSizeInt))

	// to hold collection of individual messages
	outArrayMap := make([]map[string]interface{}, batchSizeInt)

	// Process spliting the messages and add each of them to outArrayTotalMap
	for i := 0; i < batchSizeInt; i++ {
		// Check if it is the last batch of entities
		entityMap := entityArrayInf[i].(map[string](interface{}))
		entityVehicleMap := entityMap["vehicle"].(map[string](interface{}))
		entityVehicleTripMap := entityVehicleMap["trip"].(map[string](interface{}))
		entityVehiclePosMap := entityVehicleMap["position"].(map[string](interface{}))

		outArrayMap[i] = make(map[string]interface{})
		outArrayMap[i]["id"] = entityMap["id"]
		outArrayMap[i]["vehicletimestamp"] = entityVehicleMap["timestamp"]
		outArrayMap[i]["congestion_level"] = entityVehicleMap["congestion_level"]
		outArrayMap[i]["occupancy_status"] = entityVehicleMap["occupancy_status"]
		outArrayMap[i]["route_id"] = strings.Split(entityVehicleTripMap["route_id"].(string), "_")[1]
		outArrayMap[i]["trip_id"] = entityVehicleTripMap["trip_id"]
		outArrayMap[i]["start_time"] = entityVehicleTripMap["start_time"]
		outArrayMap[i]["start_date"] = entityVehicleTripMap["start_date"]
		outArrayMap[i]["schedule_relationship"] = entityVehicleTripMap["schedule_relationship"]
		outArrayMap[i]["latitude"] = entityVehiclePosMap["latitude"]
		outArrayMap[i]["longitude"] = entityVehiclePosMap["longitude"]
		outArrayMap[i]["bearing"] = entityVehiclePosMap["bearing"]
		outArrayMap[i]["speed"] = entityVehiclePosMap["speed"].(float64) * 3.6

	}
	respMsgMap := make(map[string]interface{})
	respMsgMap["respMsg"] = outArrayMap

	respMsgJson, _ := json.Marshal(respMsgMap)
	respMsgJson64 := Base64Encode(respMsgJson)

	return string(respMsgJson64)
}

/********
***	 Helper functions
********/
// ProtobufToJSON converts protocol buffer message to JSON string
func ProtobufToJSON(message proto.Message) (string, error) {
	marshaler := jsonpb.Marshaler{
		EnumsAsInts:  false,
		EmitDefaults: true,
		Indent:       "  ",
		OrigName:     true,
	}
	return marshaler.MarshalToString(message)
}

func Base64Encode(message []byte) []byte {
	b := make([]byte, base64.StdEncoding.EncodedLen(len(message)))
	base64.StdEncoding.Encode(b, message)
	return b
}

func Base64Decode(message []byte) (b []byte, err error) {
	var l int
	b = make([]byte, base64.StdEncoding.DecodedLen(len(message)))
	l, err = base64.StdEncoding.Decode(b, message)
	if err != nil {
		return
	}
	return b[:l], nil
}
